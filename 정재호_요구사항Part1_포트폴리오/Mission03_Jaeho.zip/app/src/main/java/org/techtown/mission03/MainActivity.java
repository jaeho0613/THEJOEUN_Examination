package org.techtown.mission03;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import org.techtown.mission03.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding mainBinding;
    boolean isChange = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mainBinding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(mainBinding.getRoot());

        // 수평 가능
        mainBinding.scrollView.setHorizontalScrollBarEnabled(true);
        mainBinding.scrollView2.setHorizontalScrollBarEnabled(true);

        // 클릭 이벤트
        mainBinding.buttonChangeImg.setOnClickListener(v -> changeImage());
    }

    private void changeImage() {
        if (isChange) {
            mainBinding.imageView2.setImageResource(0);
            mainBinding.imageView.setImageResource(R.drawable.img1);
            isChange = false;

        } else {
            mainBinding.imageView.setImageResource(0);
            mainBinding.imageView2.setImageResource(R.drawable.img1);
            isChange = true;
        }
    }
}