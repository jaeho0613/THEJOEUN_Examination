package com.example.mission04;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Toast;

import com.example.mission04.databinding.ActivityMainBinding;

import java.io.UnsupportedEncodingException;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();

        setContentView(view);

        binding.buttonSendMessage.setOnClickListener(v -> {
            SendMessage("전달 메시지 : " + binding.editText.getText());
        });

        binding.buttonExit.setOnClickListener(v -> {
            finish();
        });

        binding.editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                try {
                    byte[] string = s.toString().getBytes("euc-kr");
                    int byteLength = string.length;
                    binding.textView.setText(byteLength + " / 80 바이트");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                String getText = binding.editText.getText().toString();
                try {
                    byte[] bytesLength = getText.getBytes("euc-kr");
                    if (bytesLength.length > 80) {
                        s.delete(s.length() - 2, s.length() - 1);
                    }
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private void SendMessage(String data) {
        Toast.makeText(this, data, Toast.LENGTH_SHORT).show();
    }
}