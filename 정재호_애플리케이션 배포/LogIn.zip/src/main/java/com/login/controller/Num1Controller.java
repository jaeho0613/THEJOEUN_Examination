package com.login.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.login.domain.User;

@Controller
public class Num1Controller {

	@RequestMapping(value = "/main", method = RequestMethod.GET)
	public String main(Model model, HttpServletRequest request) {

		User user = (User) request.getSession().getAttribute("user");
		if (user != null) {
			System.out.println("Main user :" + user.getId());
		}

		return "main";
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String loginPro(Model model, User user, HttpServletRequest request) {

		HttpSession session = request.getSession();
		System.out.println("ID : " + user.getId());
		System.out.println("PASSWORD : " + user.getPassword());

		if (user.getId().equals("kdhong") && user.getPassword().equals("1234")) {
			System.out.println("세션 데이터 추가");
			session.setAttribute("user", user);
			return "main";
		} else {
			return "loginForm";
		}
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String loginForm(HttpServletRequest request) {
		System.out.println("세션 초기화");
		request.getSession().invalidate();
		return "redirect:loginForm";
	}

	@RequestMapping(value = "/loginForm", method = RequestMethod.GET)
	public String loginForm(Model model) {

		return "loginForm";
	}

	@RequestMapping(value = "/addMemberForm", method = RequestMethod.GET)
	public String getAddMember(Model model) {

		return "addMemberForm";
	}

	@RequestMapping(value = "/addMember", method = RequestMethod.POST)
	public String postAddMember(Model model, User user) {

		System.out.println(user.getId());
		System.out.println(user.getName());
		System.out.println(user.getPassword());
		System.out.println(user.getEmail());

		return "addMember";
	}

	@RequestMapping(value = "/multiForm", method = RequestMethod.GET)
	public String multiForm() {

		return "multiForm";
	}

	@RequestMapping(value = "/multiProcess", method = RequestMethod.POST)
	public String multiProcess(@ModelAttribute("check1") String check1, @ModelAttribute("check2") String check2,
			@ModelAttribute("check3") String check3, @ModelAttribute("check4") String check4,
			@ModelAttribute("check5") String check5, @ModelAttribute("check6") String check6) {

		return "multiProcess";
	}
}
