package com.login.domain;

import lombok.Data;

@Data
public class User {
	
	private String name;
	private String id;
	private String password;
	private String email;
}
